//Sorteio
var numSort = []
var numEsco = []
function sortearNumeros(){
    let sort
    for(var i=0; i<6; i++){
        do{
            sort = Math.ceil(Math.random() * 60)
            sort = (sort == 0) ? 1 : sort
        }while(numSort.includes(sort))

        numSort.push(sort)
    }
    console.log(numSort)
}
//Fim do sorteio


//Adicionar a lista
function addToList(num, pos){
    if(num.length == 2){
        if(numEsco.includes(num)){
            alert("Número escolhido anteriormente. Digite outro número")
        }else if(parseInt(num)>60){
            alert("O números digitado não pode ser maior que 60")
        }else{
            numEsco[pos-1] = num
        }
    }
}
//Fim do adicionar a lista


//Verificação
function verificarAcertos(){
    sortearNumeros()
    let cont = 0
    if(numEsco.length != 6){
        alert("A quantidade de números escolhidos é menor que 6.\nDigite 6 números de 1 a 60 com duas casas decimais")
    }else{
        for(var i=0; i<6; i++){
            if(numSort.includes(parseInt(numEsco[i]))){
                cont++
            }
        }
        printNumSort()
        document.getElementById('total_Acertos').innerHTML = "O total de acertos foi " + cont
    }
}
//Fim da verficação


//Mostra lista
function printNumSort(){
    for(var i=0; i<numSort.length; i++){
        let h5 = document.createElement("h5")
        h5.append(numSort[i])
        document.getElementById("lista").append(h5)
    }
}
//Fim do mostra lista
