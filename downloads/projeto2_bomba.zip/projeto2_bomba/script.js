//Bomba
function explo(){
    document.getElementById('result').innerHTML = "KABUUUMMMM!!!"
    document.getElementById('ps').innerHTML = "Obs: Era para ser uma explosão"
    document.getElementById('bomba').src = "_images/_outros/explosao.png"
    document.getElementById('bomba').alt = "explodido"
}

function voltar(){
    document.getElementById('result').innerHTML = ""
    document.getElementById('ps').innerHTML = ""
    document.getElementById('bomba').src = "_images/_outros/bomba.png"
    document.getElementById('bomba').alt = "bomba"
}
//Fim da bomba
